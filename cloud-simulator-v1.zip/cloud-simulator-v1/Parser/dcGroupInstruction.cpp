#include "dcGroupInstruction.h"
#include "dcInstruction.h"


namespace DCApplication
{
		dcGroupInstruction::dcGroupInstruction(string NameIn): dcInstruction(NameIn) {
		}




}